Install ortools for all the codes with the following script at the start of notebook :

!pip install ortools.


For Question 2:

The csv file created as the following columns : Course Number, Day, Timeslot, Room.

One constraint (Sharing room conflict) is not working properly due to some logic issue. Others are working correctly.

For number of days before and after soft constraint, do no run the soft constraint cell for checking without, and then run for checking with.
My solution for minimum number of days required adter soft constraint is 3.