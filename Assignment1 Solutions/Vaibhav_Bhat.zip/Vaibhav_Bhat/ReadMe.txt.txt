The 4th Problem requires the networkx library.

If networkx is not already installed, you can install via pip or conda by 
pip install networkx

or

conda install networkx